import React from "react";

function StoriesCard(props) {
  return (
    <div className="w-[90%] bg-white p-6 rounded-xl shadow-custom m-2">
      {/* <div className="flex">
        <img
          className="w-16 h-16 rounded-full mb-3 mr-4"
          src={props.profile}
          alt="profile"
        />
        <div>
          <h4 className="text-left">{props.name}</h4>
          <h5 className="text-left text-gray-600">{props.post}</h5>
        </div>
      </div>
      <p className="text-gray-600 text-left">{props.para}</p>
      <button className="bg-blue-400 py-2 px-3 text-blue-700 rounded-full">
        {props.btn}
      </button> */}
    </div>
  );
}

export default StoriesCard;
