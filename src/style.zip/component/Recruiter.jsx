import React from "react";

function Recruiter(props) {
  return (
    <div className="w-[90%] bg-white p-6 rounded-xl shadow-custom m-2">
      <img
        className="w-16 h-16 rounded-full mb-3 mr-4"
        src={props.recCompany}
        alt="profile"
      />
      <p className="text-gray-600 text-left">{props.recPara}</p>
      <button className="bg-blue-400 my-4 py-2 px-3 text-blue-700 rounded-full">
        {props.recBtn}
      </button>
      <div className="flex">
        <img
          className="w-16 h-16 rounded-full mb-3 mr-4"
          src={props.recProfile}
          alt="profile"
        />
        <div>
          <h4 className="text-left">{props.recName}</h4>
          <h5 className="text-left text-blue-400 text-base">{props.recPost}</h5>
        </div>
      </div>
    </div>
  );
}

export default Recruiter;
